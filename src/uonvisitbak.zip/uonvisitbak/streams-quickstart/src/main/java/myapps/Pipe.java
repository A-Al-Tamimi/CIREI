package myapps;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;

import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Pipe {   public static void main(String[] args) {
       //Properties from the input data to remove
	 //The source data has a known structure containing 6 properties, 3 of which are irrelevant; attributes and context in particular are objects of variable internal structure, so are harder to process without more thorough preprocessing and filtration
	 //For monitoring purposes, entity_id, state and last_updated are the most important.  last_updated and last_changed are distinct; the latter only changes in response to state changes, while the former also changes when attributes of an entity change
       final String[] remove_list = new String[] {
           "entity_id",
           //"state",
           "attributes",
           "last_changed",
           "last_updated",
           "context"
       };


       Properties props = new Properties();
       props.put(StreamsConfig.APPLICATION_ID_CONFIG, "streams-pipe-counter-4");
       props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
       props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
       props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());


       //Defining of the streaming application
       final StreamsBuilder builder = new StreamsBuilder();
       
        builder.<String,String>stream("home_assistant").flatMapValues(
            value -> {
                JsonObject json = JsonParser.parseString(value).getAsJsonObject();

                if(json.get("entity_id").getAsString().equals("counter.testcounter")){
                    for(String s: remove_list){
                        if (json.has(s)){
                            json.remove(s);
                        }
                    }
                    return Arrays.asList(json.toString());
                }else{
                    return Collections.emptyList();
                }
            }
        ).to("ha_counter_newest");


       //Finalising the stream application; it can now be started
       final Topology topology = builder.build();
       final KafkaStreams streams = new KafkaStreams(topology, props);
       final CountDownLatch latch = new CountDownLatch(1);


       //Attach shutdown handler to catch control-c
       Runtime.getRuntime().addShutdownHook(new Thread("streams-shutdown-hook") {
           @Override
           public void run() {
               streams.close();
               latch.countDown();
           }
       });


       try {
           streams.start();
           latch.await();
       } catch (Throwable e) {
           System.exit(1);
       }
       System.exit(0);
   }
}
